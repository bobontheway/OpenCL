import java.lang.Comparable;

public interface Sorter {
    public abstract void sort(Comparable[] data);
}
